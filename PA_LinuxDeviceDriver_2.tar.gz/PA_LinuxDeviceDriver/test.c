#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main(void)
{
    int fd;

    fd = open("/dev/cdata", O_RDWR);
    cloes(fd);
}
